"use client";

import App from "@/components/App";

export default function Page() {
  return (
    <main style={{ minHeight: "100vh", paddingBottom: "2rem" }}>
      <App />
    </main>
  );
}
