"use client";

import { useState, useEffect } from "react";
import SignaturePad from "./SignaturePad";

const RADNICI = ["Luka", "Nikola", "Dragan"];
const NALOZI_KEY = "rn-nalozi-v2";
const odgKey = (ime: string) => `rn-odg-${ime.toLowerCase()}-v2`;

interface Nalog {
  id: string;
  opis: string;
  dodeljen: string;
  datum: string;
  status: "aktivan" | "zavrsen";
}

interface Slika {
  name: string;
  data: string;
}

interface Odgovor {
  nalogId: string;
  nalogOpis: string;
  opis: string;
  lokacija: string;
  napomena: string;
  slike: Slika[];
  potpis: string | null;
  potpisRadnik: string | null;
  zavrsen: boolean;
  vreme: string;
}

interface Forma {
  opis: string;
  lokacija: string;
  napomena: string;
  slike: Slika[];
  potpis: string | null;
  potpisRadnik: string | null;
  zavrsen: boolean;
}

function genId(arr: Nalog[]) {
  return `NAL-${(arr.length + 1).toString().padStart(3, "0")}`;
}

const s = {
  card: {
    background: "var(--color-background-primary)",
    border: "0.5px solid var(--color-border-tertiary)",
    borderRadius: "var(--border-radius-lg)",
    padding: "1rem 1.25rem",
    marginBottom: 12,
  } as React.CSSProperties,
  label: {
    display: "block",
    fontSize: 13,
    color: "var(--color-text-secondary)",
    marginBottom: 6,
    fontWeight: 500,
  } as React.CSSProperties,
  badge: (color: string): React.CSSProperties => ({
    fontSize: 12,
    padding: "2px 10px",
    borderRadius: 20,
    background: `var(--color-background-${color})`,
    color: `var(--color-text-${color})`,
    display: "inline-block",
  }),
  header: (bg: string): React.CSSProperties => ({
    background: bg,
    color: "#fff",
    padding: "14px 16px",
    display: "flex",
    alignItems: "center",
    gap: 12,
  }),
  backBtn: {
    background: "none",
    border: "none",
    color: "#fff",
    cursor: "pointer",
    fontSize: 18,
    padding: 0,
    lineHeight: 1,
  } as React.CSSProperties,
  row: {
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
  } as React.CSSProperties,
  pill: { display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12 } as React.CSSProperties,
};

// localStorage helpers
function lsGet(key: string): string | null {
  try { return localStorage.getItem(key); } catch { return null; }
}
function lsSet(key: string, val: string) {
  try { localStorage.setItem(key, val); } catch {}
}

export default function App() {
  const [screen, setScreen] = useState("login");
  const [role, setRole] = useState<string | null>(null);
  const [nalozi, setNalozi] = useState<Nalog[]>([]);
  const [odgovori, setOdgovori] = useState<Record<string, Odgovor[]>>({});
  const [loading, setLoading] = useState(true);
  const [aktivni, setAktivni] = useState<Nalog | null>(null);
  const [noviOpis, setNoviOpis] = useState("");
  const [noviRadnik, setNoviRadnik] = useState("Luka");
  const [forma, setForma] = useState<Forma>({
    opis: "", lokacija: "", napomena: "", slike: [], potpis: null, potpisRadnik: null, zavrsen: false,
  });
  const [sefTab, setSefTab] = useState("novi");
  const [filter, setFilter] = useState("svi");
  const [saving, setSaving] = useState(false);
  const [potpisSnimljen, setPotpisSnimljen] = useState(false);
  const [potpisRadnikSnimljen, setPotpisRadnikSnimljen] = useState(false);

  useEffect(() => { loadAll(); }, []);

  const loadAll = () => {
    setLoading(true);
    try {
      const raw = lsGet(NALOZI_KEY);
      const n: Nalog[] = raw ? JSON.parse(raw) : [];
      setNalozi(n);
      const od: Record<string, Odgovor[]> = {};
      for (const ime of RADNICI) {
        const r = lsGet(odgKey(ime));
        od[ime] = r ? JSON.parse(r) : [];
      }
      setOdgovori(od);
    } catch {}
    setLoading(false);
  };

  const saveNalozi = (n: Nalog[]) => {
    setNalozi(n);
    lsSet(NALOZI_KEY, JSON.stringify(n));
  };

  const saveOdg = (ime: string, od: Odgovor[]) => {
    setOdgovori((prev) => ({ ...prev, [ime]: od }));
    lsSet(odgKey(ime), JSON.stringify(od));
  };

  const kreiraj = () => {
    if (!noviOpis.trim()) return;
    const n: Nalog = {
      id: genId(nalozi),
      opis: noviOpis.trim(),
      dodeljen: noviRadnik,
      datum: new Date().toLocaleDateString("sr-RS"),
      status: "aktivan",
    };
    saveNalozi([...nalozi, n]);
    setNoviOpis("");
  };

  const obrisi = (id: string) => {
    saveNalozi(nalozi.filter((n) => n.id !== id));
  };

  const handleSlike = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files) return;
    Array.from(e.target.files).forEach((f) => {
      const rd = new FileReader();
      rd.onload = (ev) =>
        setForma((prev) => ({
          ...prev,
          slike: [...prev.slike, { name: f.name, data: ev.target!.result as string }],
        }));
      rd.readAsDataURL(f);
    });
  };

  const submitOdg = () => {
    setSaving(true);
    const odg: Odgovor = {
      nalogId: aktivni!.id,
      nalogOpis: aktivni!.opis,
      opis: forma.opis,
      lokacija: forma.lokacija,
      napomena: forma.napomena,
      slike: forma.slike,
      potpis: forma.potpis,
      potpisRadnik: forma.potpisRadnik,
      zavrsen: forma.zavrsen,
      vreme: new Date().toLocaleString("sr-RS"),
    };
    if (forma.zavrsen) {
      saveNalozi(nalozi.map((n) => (n.id === aktivni!.id ? { ...n, status: "zavrsen" } : n)));
    }
    saveOdg(role!, [...(odgovori[role!] || []), odg]);
    setAktivni(null);
    setForma({ opis: "", lokacija: "", napomena: "", slike: [], potpis: null, potpisRadnik: null, zavrsen: false });
    setPotpisSnimljen(false);
    setPotpisRadnikSnimljen(false);
    setSaving(false);
  };

  if (loading)
    return (
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: 300, color: "var(--color-text-secondary)", fontSize: 15 }}>
        Učitavanje...
      </div>
    );

  // LOGIN
  if (screen === "login")
    return (
      <div style={{ maxWidth: 360, margin: "2rem auto", padding: "0 1rem" }}>
        <div style={{ textAlign: "center", marginBottom: 28 }}>
          <div style={{ fontSize: 36, marginBottom: 8 }}>📋</div>
          <h1 style={{ fontSize: 22, fontWeight: 500, margin: "0 0 4px", color: "var(--color-text-primary)" }}>Radni nalozi</h1>
          <p style={{ color: "var(--color-text-secondary)", margin: 0, fontSize: 14 }}>Prijavi se kao šef ili radnik</p>
        </div>
        <div style={s.card}>
          <p style={{ ...s.label, marginBottom: 10 }}>Šef</p>
          <button
            onClick={() => { setRole("sef"); setScreen("sef"); }}
            style={{ width: "100%", padding: "10px", borderRadius: "var(--border-radius-md)", background: "var(--color-background-info)", border: "none", color: "var(--color-text-info)", fontSize: 15, fontWeight: 500, cursor: "pointer" }}
          >
            Prijavi se kao šef
          </button>
        </div>
        <div style={s.card}>
          <p style={{ ...s.label, marginBottom: 10 }}>Radnik</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {RADNICI.map((ime) => (
              <button
                key={ime}
                onClick={() => { setRole(ime); setScreen("radnik"); }}
                style={{ padding: "10px", borderRadius: "var(--border-radius-md)", background: "var(--color-background-success)", border: "none", color: "var(--color-text-success)", fontSize: 15, fontWeight: 500, cursor: "pointer" }}
              >
                {ime}
              </button>
            ))}
          </div>
        </div>
      </div>
    );

  // SEF
  if (screen === "sef") {
    const prikazani =
      filter === "svi"
        ? [...nalozi].reverse()
        : [...nalozi].reverse().filter((n) =>
            filter === "aktivni" ? n.status === "aktivan" : n.status === "zavrsen"
          );
    return (
      <div style={{ minHeight: 400 }}>
        <div style={s.header("#185FA5")}>
          <button style={s.backBtn} onClick={() => setScreen("login")}>←</button>
          <div>
            <div style={{ fontWeight: 500, fontSize: 16 }}>Šef panel</div>
            <div style={{ fontSize: 12, opacity: 0.85 }}>
              {nalozi.filter((n) => n.status === "aktivan").length} aktivnih ·{" "}
              {nalozi.filter((n) => n.status === "zavrsen").length} završenih
            </div>
          </div>
        </div>
        <div style={{ maxWidth: 600, margin: "0 auto", padding: "1rem" }}>
          <div style={s.pill}>
            {["novi", "nalozi"].map((t) => (
              <button
                key={t}
                onClick={() => setSefTab(t)}
                style={{ padding: "6px 16px", borderRadius: 20, border: "0.5px solid var(--color-border-secondary)", background: sefTab === t ? "var(--color-background-info)" : "var(--color-background-primary)", color: sefTab === t ? "var(--color-text-info)" : "var(--color-text-primary)", cursor: "pointer", fontSize: 13, fontWeight: 500 }}
              >
                {t === "novi" ? "+ Novi nalog" : "Svi nalozi"}
              </button>
            ))}
          </div>

          {sefTab === "novi" && (
            <div style={s.card}>
              <label style={s.label}>Opis posla</label>
              <textarea
                value={noviOpis}
                onChange={(e) => setNoviOpis(e.target.value)}
                placeholder="Opiši šta treba da se uradi..."
                style={{ width: "100%", height: 90, resize: "vertical", boxSizing: "border-box", fontFamily: "inherit", fontSize: 14 }}
              />
              <label style={{ ...s.label, marginTop: 12 }}>Dodeli radniku</label>
              <select
                value={noviRadnik}
                onChange={(e) => setNoviRadnik(e.target.value)}
                style={{ width: "100%", boxSizing: "border-box" }}
              >
                {RADNICI.map((r) => <option key={r}>{r}</option>)}
              </select>
              <button
                onClick={kreiraj}
                style={{ marginTop: 12, width: "100%", padding: "10px", borderRadius: "var(--border-radius-md)", background: "var(--color-background-info)", border: "none", color: "var(--color-text-info)", fontSize: 15, fontWeight: 500, cursor: "pointer" }}
              >
                Kreiraj nalog
              </button>
            </div>
          )}

          {sefTab === "nalozi" && (
            <>
              <div style={s.pill}>
                {["svi", "aktivni", "zavrseni"].map((f) => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    style={{ padding: "5px 14px", borderRadius: 20, border: "0.5px solid var(--color-border-secondary)", background: filter === f ? "var(--color-background-secondary)" : "var(--color-background-primary)", color: "var(--color-text-primary)", cursor: "pointer", fontSize: 12 }}
                  >
                    {f === "svi" ? "Svi" : f === "aktivni" ? "Aktivni" : "Završeni"}
                  </button>
                ))}
              </div>
              {prikazani.length === 0 && (
                <div style={{ color: "var(--color-text-secondary)", textAlign: "center", padding: "2rem 0", fontSize: 14 }}>Nema naloga</div>
              )}
              {prikazani.map((n) => {
                const radOdg = (odgovori[n.dodeljen] || []).filter((o) => o.nalogId === n.id);
                return (
                  <div
                    key={n.id}
                    style={{ ...s.card, borderLeft: `3px solid ${n.status === "zavrsen" ? "var(--color-text-success)" : "var(--color-text-warning)"}`, borderRadius: "0 var(--border-radius-lg) var(--border-radius-lg) 0" }}
                  >
                    <div style={s.row}>
                      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                        <span style={{ fontWeight: 500, fontSize: 13, color: "var(--color-text-info)" }}>{n.id}</span>
                        <span style={s.badge(n.status === "zavrsen" ? "success" : "warning")}>
                          {n.status === "zavrsen" ? "Završen" : "Aktivan"}
                        </span>
                      </div>
                      <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                        <span style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>{n.dodeljen}</span>
                        <button
                          onClick={() => obrisi(n.id)}
                          style={{ background: "none", border: "none", cursor: "pointer", color: "var(--color-text-danger)", fontSize: 14, padding: "0 2px" }}
                        >✕</button>
                      </div>
                    </div>
                    <p style={{ margin: "8px 0 4px", fontSize: 14, color: "var(--color-text-primary)" }}>{n.opis}</p>
                    <div style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>{n.datum}</div>
                    {radOdg.map((o, i) => (
                      <div key={i} style={{ marginTop: 10, padding: "10px 12px", background: "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)", fontSize: 13 }}>
                        <div style={{ fontWeight: 500, marginBottom: 6, color: "var(--color-text-primary)" }}>Izveštaj — {o.vreme}</div>
                        {o.opis && <div style={{ marginBottom: 3 }}><b>Opis:</b> {o.opis}</div>}
                        {o.lokacija && <div style={{ marginBottom: 3 }}><b>Lokacija:</b> {o.lokacija}</div>}
                        {o.napomena && <div style={{ marginBottom: 3 }}><b>Napomena:</b> {o.napomena}</div>}
                        {o.slike?.length > 0 && (
                          <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 8 }}>
                            {o.slike.map((sl, si) => (
                              <img key={si} src={sl.data} alt={sl.name} style={{ width: 72, height: 72, objectFit: "cover", borderRadius: "var(--border-radius-md)", border: "0.5px solid var(--color-border-tertiary)" }} />
                            ))}
                          </div>
                        )}
                        {(o.potpisRadnik || o.potpis) && (
                          <div style={{ display: "flex", gap: 12, marginTop: 8, flexWrap: "wrap" }}>
                            {o.potpisRadnik && (
                              <div>
                                <div style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 4 }}>Potpis radnika:</div>
                                <img src={o.potpisRadnik} alt="potpis radnika" style={{ maxWidth: 180, height: 55, objectFit: "contain", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", background: "#fff", display: "block" }} />
                              </div>
                            )}
                            {o.potpis && (
                              <div>
                                <div style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: 4 }}>Potpis mušterije:</div>
                                <img src={o.potpis} alt="potpis mušterije" style={{ maxWidth: 180, height: 55, objectFit: "contain", border: "0.5px solid var(--color-border-tertiary)", borderRadius: "var(--border-radius-md)", background: "#fff", display: "block" }} />
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                );
              })}
            </>
          )}
        </div>
      </div>
    );
  }

  // RADNIK — forma
  if (screen === "radnik" && aktivni) {
    return (
      <div style={{ minHeight: 400 }}>
        <div style={s.header("#0F6E56")}>
          <button
            style={s.backBtn}
            onClick={() => {
              setAktivni(null);
              setForma({ opis: "", lokacija: "", napomena: "", slike: [], potpis: null, potpisRadnik: null, zavrsen: false });
              setPotpisSnimljen(false);
              setPotpisRadnikSnimljen(false);
            }}
          >←</button>
          <div>
            <div style={{ fontWeight: 500, fontSize: 16 }}>{aktivni.id}</div>
            <div style={{ fontSize: 12, opacity: 0.85 }}>Popuni izveštaj</div>
          </div>
        </div>
        <div style={{ maxWidth: 600, margin: "0 auto", padding: "1rem" }}>
          <div style={{ ...s.card, background: "var(--color-background-success)", border: "0.5px solid var(--color-border-success)" }}>
            <div style={{ fontSize: 12, fontWeight: 500, color: "var(--color-text-success)", marginBottom: 4 }}>RADNI NALOG</div>
            <div style={{ fontSize: 14, color: "var(--color-text-primary)" }}>{aktivni.opis}</div>
          </div>

          <div style={s.card}>
            <label style={s.label}>Opis urađenog posla</label>
            <textarea
              value={forma.opis}
              onChange={(e) => setForma((f) => ({ ...f, opis: e.target.value }))}
              placeholder="Opiši šta si uradio..."
              style={{ width: "100%", height: 100, resize: "vertical", boxSizing: "border-box", fontFamily: "inherit", fontSize: 14 }}
            />

            <label style={{ ...s.label, marginTop: 14 }}>Lokacija</label>
            <input
              value={forma.lokacija}
              onChange={(e) => setForma((f) => ({ ...f, lokacija: e.target.value }))}
              placeholder="Gde je posao obavljen..."
              style={{ width: "100%", boxSizing: "border-box" }}
            />

            <label style={{ ...s.label, marginTop: 14 }}>Napomena</label>
            <textarea
              value={forma.napomena}
              onChange={(e) => setForma((f) => ({ ...f, napomena: e.target.value }))}
              placeholder="Opciono..."
              style={{ width: "100%", height: 70, resize: "vertical", boxSizing: "border-box", fontFamily: "inherit", fontSize: 14 }}
            />

            <label style={{ ...s.label, marginTop: 14 }}>Slike</label>
            <input type="file" accept="image/*" multiple onChange={handleSlike} id="img-inp" style={{ display: "none" }} />
            <label
              htmlFor="img-inp"
              style={{ display: "block", textAlign: "center", padding: "9px", borderRadius: "var(--border-radius-md)", border: "0.5px solid var(--color-border-secondary)", cursor: "pointer", fontSize: 14, color: "var(--color-text-secondary)" }}
            >
              + Dodaj slike
            </label>
            {forma.slike.length > 0 && (
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 10 }}>
                {forma.slike.map((sl, i) => (
                  <div key={i} style={{ position: "relative" }}>
                    <img src={sl.data} alt={sl.name} style={{ width: 80, height: 80, objectFit: "cover", borderRadius: "var(--border-radius-md)", border: "0.5px solid var(--color-border-tertiary)", display: "block" }} />
                    <button
                      onClick={() => setForma((f) => ({ ...f, slike: f.slike.filter((_, si) => si !== i) }))}
                      style={{ position: "absolute", top: -6, right: -6, width: 20, height: 20, borderRadius: "50%", background: "var(--color-background-danger)", border: "none", color: "var(--color-text-danger)", cursor: "pointer", fontSize: 13, display: "flex", alignItems: "center", justifyContent: "center" }}
                    >✕</button>
                  </div>
                ))}
              </div>
            )}

            <label style={{ ...s.label, marginTop: 14 }}>Potpis radnika</label>
            {!potpisRadnikSnimljen ? (
              <SignaturePad
                onSave={(data) => {
                  if (data) { setForma((f) => ({ ...f, potpisRadnik: data })); setPotpisRadnikSnimljen(true); }
                }}
              />
            ) : (
              <div style={{ border: "0.5px solid var(--color-border-secondary)", borderRadius: "var(--border-radius-md)", padding: 10, background: "var(--color-background-secondary)" }}>
                <div style={{ fontSize: 12, color: "var(--color-text-success)", marginBottom: 6, fontWeight: 500 }}>Potpis radnika snimljen</div>
                <img src={forma.potpisRadnik!} alt="potpis radnika" style={{ maxWidth: "100%", height: 70, objectFit: "contain", background: "#fff", borderRadius: "var(--border-radius-md)", display: "block" }} />
                <button
                  onClick={() => { setForma((f) => ({ ...f, potpisRadnik: null })); setPotpisRadnikSnimljen(false); }}
                  style={{ marginTop: 8, fontSize: 12, padding: "5px 12px", borderRadius: "var(--border-radius-md)", border: "0.5px solid var(--color-border-secondary)", background: "none", color: "var(--color-text-secondary)", cursor: "pointer" }}
                >
                  Ponovi potpis
                </button>
              </div>
            )}

            <label style={{ ...s.label, marginTop: 14 }}>Potpis mušterije</label>
            {!potpisSnimljen ? (
              <SignaturePad
                onSave={(data) => {
                  if (data) { setForma((f) => ({ ...f, potpis: data })); setPotpisSnimljen(true); }
                }}
              />
            ) : (
              <div style={{ border: "0.5px solid var(--color-border-secondary)", borderRadius: "var(--border-radius-md)", padding: 10, background: "var(--color-background-secondary)" }}>
                <div style={{ fontSize: 12, color: "var(--color-text-success)", marginBottom: 6, fontWeight: 500 }}>Potpis mušterije snimljen</div>
                <img src={forma.potpis!} alt="potpis mušterije" style={{ maxWidth: "100%", height: 70, objectFit: "contain", background: "#fff", borderRadius: "var(--border-radius-md)", display: "block" }} />
                <button
                  onClick={() => { setForma((f) => ({ ...f, potpis: null })); setPotpisSnimljen(false); }}
                  style={{ marginTop: 8, fontSize: 12, padding: "5px 12px", borderRadius: "var(--border-radius-md)", border: "0.5px solid var(--color-border-secondary)", background: "none", color: "var(--color-text-secondary)", cursor: "pointer" }}
                >
                  Ponovi potpis
                </button>
              </div>
            )}

            <div
              onClick={() => setForma((f) => ({ ...f, zavrsen: !f.zavrsen }))}
              style={{ marginTop: 16, display: "flex", alignItems: "center", gap: 10, padding: "12px 14px", background: forma.zavrsen ? "var(--color-background-success)" : "var(--color-background-secondary)", borderRadius: "var(--border-radius-md)", cursor: "pointer", border: "0.5px solid var(--color-border-tertiary)" }}
            >
              <div style={{ width: 22, height: 22, borderRadius: 6, border: `2px solid ${forma.zavrsen ? "var(--color-text-success)" : "var(--color-border-secondary)"}`, background: forma.zavrsen ? "var(--color-text-success)" : "transparent", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff", fontSize: 13, flexShrink: 0 }}>
                {forma.zavrsen && "✓"}
              </div>
              <span style={{ fontSize: 14, fontWeight: 500, color: forma.zavrsen ? "var(--color-text-success)" : "var(--color-text-primary)" }}>Označiti kao završen</span>
            </div>

            <button
              onClick={submitOdg}
              disabled={saving}
              style={{ marginTop: 14, width: "100%", padding: "11px", borderRadius: "var(--border-radius-md)", background: "var(--color-background-success)", border: "none", color: "var(--color-text-success)", fontSize: 15, fontWeight: 500, cursor: "pointer", opacity: saving ? 0.7 : 1 }}
            >
              {saving ? "Slanje..." : "Pošalji izveštaj"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  // RADNIK — lista
  if (screen === "radnik") {
    const moji = nalozi.filter((n) => n.dodeljen === role);
    const aktivniN = moji.filter((n) => n.status === "aktivan");
    const zavrseniN = moji.filter((n) => n.status === "zavrsen");
    return (
      <div style={{ minHeight: 400 }}>
        <div style={s.header("#0F6E56")}>
          <button style={s.backBtn} onClick={() => setScreen("login")}>←</button>
          <div>
            <div style={{ fontWeight: 500, fontSize: 16 }}>{role}</div>
            <div style={{ fontSize: 12, opacity: 0.85 }}>{aktivniN.length} aktivnih naloga</div>
          </div>
        </div>
        <div style={{ maxWidth: 600, margin: "0 auto", padding: "1rem" }}>
          {moji.length === 0 && (
            <div style={{ ...s.card, textAlign: "center", padding: "2rem", color: "var(--color-text-secondary)", fontSize: 14 }}>Nema dodeljenih naloga</div>
          )}
          {aktivniN.length > 0 && (
            <>
              <p style={{ ...s.label, marginBottom: 8 }}>Aktivni nalozi</p>
              {aktivniN.map((n) => (
                <div
                  key={n.id}
                  onClick={() => setAktivni(n)}
                  style={{ ...s.card, cursor: "pointer", borderLeft: "3px solid var(--color-text-warning)", borderRadius: "0 var(--border-radius-lg) var(--border-radius-lg) 0" }}
                >
                  <div style={s.row}>
                    <span style={{ fontWeight: 500, fontSize: 13, color: "var(--color-text-info)" }}>{n.id}</span>
                    <span style={s.badge("warning")}>Aktivan</span>
                  </div>
                  <p style={{ margin: "8px 0 6px", fontSize: 14, color: "var(--color-text-primary)" }}>{n.opis}</p>
                  <div style={{ fontSize: 12, color: "var(--color-text-success)", fontWeight: 500 }}>Tapni da popuniš →</div>
                </div>
              ))}
            </>
          )}
          {zavrseniN.length > 0 && (
            <>
              <p style={{ ...s.label, marginTop: 8, marginBottom: 8 }}>Završeni nalozi</p>
              {zavrseniN.map((n) => (
                <div
                  key={n.id}
                  style={{ ...s.card, borderLeft: "3px solid var(--color-text-success)", borderRadius: "0 var(--border-radius-lg) var(--border-radius-lg) 0", opacity: 0.75 }}
                >
                  <div style={s.row}>
                    <span style={{ fontWeight: 500, fontSize: 13, color: "var(--color-text-info)" }}>{n.id}</span>
                    <span style={s.badge("success")}>Završen</span>
                  </div>
                  <p style={{ margin: "8px 0 0", fontSize: 14, color: "var(--color-text-primary)" }}>{n.opis}</p>
                </div>
              ))}
            </>
          )}
        </div>
      </div>
    );
  }

  return null;
}
