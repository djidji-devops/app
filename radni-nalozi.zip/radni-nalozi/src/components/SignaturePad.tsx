"use client";

import { useRef, useState } from "react";

interface SignaturePadProps {
  onSave: (data: string | null) => void;
}

export default function SignaturePad({ onSave }: SignaturePadProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const drawing = useRef(false);
  const [hasSig, setHasSig] = useState(false);

  const getPos = (
    e: React.MouseEvent | React.TouchEvent,
    canvas: HTMLCanvasElement
  ) => {
    const rect = canvas.getBoundingClientRect();
    const src =
      "touches" in e
        ? (e as React.TouchEvent).touches[0]
        : (e as React.MouseEvent);
    return { x: src.clientX - rect.left, y: src.clientY - rect.top };
  };

  const start = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    const { x, y } = getPos(e, canvas);
    ctx.beginPath();
    ctx.moveTo(x, y);
    drawing.current = true;
  };

  const move = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    if (!drawing.current) return;
    const canvas = canvasRef.current!;
    const ctx = canvas.getContext("2d")!;
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.strokeStyle = "#1e293b";
    const { x, y } = getPos(e, canvas);
    ctx.lineTo(x, y);
    ctx.stroke();
    setHasSig(true);
  };

  const end = (e: React.MouseEvent | React.TouchEvent) => {
    e.preventDefault();
    drawing.current = false;
  };

  const clear = () => {
    const canvas = canvasRef.current!;
    canvas.getContext("2d")!.clearRect(0, 0, canvas.width, canvas.height);
    setHasSig(false);
    onSave(null);
  };

  const save = () => {
    if (!hasSig) return;
    const data = canvasRef.current!.toDataURL("image/png");
    onSave(data);
  };

  return (
    <div>
      <div
        style={{
          position: "relative",
          border: "0.5px solid var(--color-border-secondary)",
          borderRadius: "var(--border-radius-md)",
          overflow: "hidden",
          background: "#fff",
          touchAction: "none",
        }}
      >
        <canvas
          ref={canvasRef}
          width={520}
          height={140}
          style={{ display: "block", width: "100%", height: 140, cursor: "crosshair" }}
          onMouseDown={start}
          onMouseMove={move}
          onMouseUp={end}
          onMouseLeave={end}
          onTouchStart={start}
          onTouchMove={move}
          onTouchEnd={end}
        />
        {!hasSig && (
          <div
            style={{
              position: "absolute",
              top: "50%",
              left: "50%",
              transform: "translate(-50%,-50%)",
              fontSize: 13,
              color: "#94a3b8",
              pointerEvents: "none",
              userSelect: "none",
            }}
          >
            Potpišite se ovde prstom
          </div>
        )}
      </div>
      <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
        <button
          onClick={clear}
          style={{
            flex: 1,
            padding: "8px",
            borderRadius: "var(--border-radius-md)",
            border: "0.5px solid var(--color-border-secondary)",
            background: "var(--color-background-secondary)",
            color: "var(--color-text-secondary)",
            cursor: "pointer",
            fontSize: 13,
          }}
        >
          Obriši
        </button>
        <button
          onClick={save}
          disabled={!hasSig}
          style={{
            flex: 2,
            padding: "8px",
            borderRadius: "var(--border-radius-md)",
            border: "none",
            background: hasSig
              ? "var(--color-background-success)"
              : "var(--color-background-secondary)",
            color: hasSig
              ? "var(--color-text-success)"
              : "var(--color-text-secondary)",
            cursor: hasSig ? "pointer" : "default",
            fontSize: 13,
            fontWeight: 500,
          }}
        >
          Sačuvaj potpis
        </button>
      </div>
    </div>
  );
}
